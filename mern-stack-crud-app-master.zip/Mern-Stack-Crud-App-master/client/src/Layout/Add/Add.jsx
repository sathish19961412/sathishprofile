import React, { Fragment } from 'react';
import AddStudent from '../../components/AddStudent/AddStudent';

const Add = () => {
  return (
    <Fragment>
      <AddStudent />
    </Fragment>
  );
};

export default Add;